<?php
$consumer_key = 'your_consumer_key';
$consumer_secret = 'your_consumer_secret';
?>
