<?php
$consumer_key = '{ENTER_YOUR_CONSUMER_KEY}';
$consumer_secret = '{ENTER_YOUR_CONSUMER_SECRET}';
?>
