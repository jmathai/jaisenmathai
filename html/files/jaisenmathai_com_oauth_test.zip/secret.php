<?php
$consumer_key = '{your_key_here}';
$consumer_secret = '{your secret_here}';
?>
