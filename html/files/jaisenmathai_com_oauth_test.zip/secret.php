<?php
$consumer_key = 'your key here';
$consumer_secret = 'your secret here';
?>
